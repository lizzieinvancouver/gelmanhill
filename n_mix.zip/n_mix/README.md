# n_mix
N-mixture models for population ecology
